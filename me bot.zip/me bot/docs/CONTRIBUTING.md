Contributing would be great as i'm a sole developer for this bot.

You can help contribute by:
* Translation language files (help with previous translations or make support for another language)
* Optimization on files. (Know a better way on a function, make a pull request and I'll have a look)
* Donating (Donating helps me stay motivated to providing open source code, that anyone can use)
