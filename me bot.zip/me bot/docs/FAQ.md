**Frequently Asked Questions.**

***

Getting this error `[10:33:06]: ERROR Privileged intent provided is not enabled or whitelisted.` ?
* You need to enable the privileged intent "server member intent" for you bot. If you're bot is over 100 servers you will need to verify your bot.

Getting an error like this on lavalink load up: `has been compiled by a more recent version of the java runtime (class fileversion 55.0), this version of the java runtime only recongises up to x..`
* You need to update your java version to java 11 minimum. You can download java here: https://adoptopenjdk.net/
