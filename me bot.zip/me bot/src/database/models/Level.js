const { Schema, model } = require('mongoose');

const rankSchema = Schema({
	userID: String,
	guildID: String,
	Xp: Number,
	Level: Number,
    money:Number,
    job:String
});

module.exports = model('Ranks', rankSchema);
