// Dependencies
const Command = require('../../structures/Command.js'),
      Guild = require('../../structures/Guild.js');
const { Embed } = require('../../utils');
const { MessageActionRow, MessageButton , MessageSelectMenu } = require('discord.js');
/**
 * CustomCommand command
 * @extends {Command}
*/
module.exports = class setup extends Command {
	/**
 	 * @param {Client} client The instantiating client
 	 * @param {CommandData} data The data for the command
	*/
	constructor(bot) {
		// MORE COMMAND SETTINGS CAN BE FOUND IN src/structures/Command
		super(bot, {
			name: 'setup',
			guildOnly: true,
			dirname: __dirname,
            ownerOnly: true,
			description: 'create a Music channel.',
			usage: 'setup',
			cooldown: 5000,
			//examples: ['AN', 'ARRAY', 'OF', 'EXAMPLES'],
			// set to false if u don't want it a slash command VV
			slash: false,
			// The options for slash command https://discord.js.org/#/docs/discord.js/stable/typedef/CommandInteractionOption
			//options: [],
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
	 * @param {settings} settings The settings of the channel the command ran in
 	 * @readonly
	*/
	async run(bot, message, settings ) {
const guild = message.guild;
		// A VERY COOL COMMAND
const VahshiChannel = guild.channels.create('😈・Vahshi-Music', { type: 'category' }).then(async result => {
await updateMusicchannel(message.guild, result.id);

const picture =  new Embed(bot, guild)
.setColor('#4853d8')
.setImage(require('../../assets/json/defaultGuildSettings.json').PlayerImage).setTimestamp(false);
//----------------------------------------------
    function guidimage(){
    if(!guild.iconURL()){
      return require('../../assets/json/defaultGuildSettings.json').PlayerIcon;
    }else{
      return guild.iconURL();
    }
    }
   
const PlayerMusic =  new Embed(bot, guild)
.setColor('#4853d8')
.setAuthor({ name: `» Lotus Music ${require('../../assets/json/defaultGuildSettings.json').PlayerVersion}` , iconURL: `${guidimage()}`})
.setTitle("No song playing currently")
.setDescription(`>>> I support <:YTicon:939355466402791454> Youtube, <:SPicon:939355458878201948> Spotify, <:SCicon:939355451332657152> Soundcloud and <:MPicon:939355445062144021> Direct MP3 Links!`)
.setImage(require('../../assets/json/defaultGuildSettings.json').PlayerImageIdle)
.setFooter({ text: 'Lotus Music', iconURL: require('../../assets/json/defaultGuildSettings.json').PlayerIcon })
.setTimestamp(false);
//----------------------------------------------
    const SelectButton = new MessageActionRow().addComponents(
    new MessageButton().setCustomId('pause').setLabel('⏸️ Pause').setStyle('SECONDARY').setDisabled(true),
    new MessageButton().setCustomId('skip').setLabel('⏭️ Skip').setStyle('PRIMARY').setDisabled(true),
    new MessageButton().setCustomId('stop').setLabel('⏹️ Stop').setStyle('DANGER').setDisabled(true),
    new MessageButton().setCustomId('shuffle').setLabel('🔀 Shuffle').setStyle('PRIMARY').setDisabled(true),
    new MessageButton().setCustomId('queue').setLabel('🔂 Loop').setStyle('SUCCESS').setDisabled(true),
      );   
    
    
result.send({content: `
`, embeds: [picture , PlayerMusic ] , components: [ SelectButton ] }).then(async MsgM => {
await updateMusiccmessage(message.guild, MsgM.id);
});

});


        async function updateMusicchannel(guild, Musicchannel) {
			try {
				await guild.updateGuild({ musicChannel: Musicchannel });
				//return message.channel.success("Channel is created and Save");
			} catch (err) {
				bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
				message.channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }).then(m => m.timedDelete({ timeout: 5000 }));
			}
		}
            async function updateMusiccmessage(guild, musicmssage) {
			try {
				await guild.updateGuild({ musicMessage: musicmssage });
				return message.channel.success("چنل موزیک با موفقیت ساخته شد");
			} catch (err) {
				bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
				message.channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }).then(m => m.timedDelete({ timeout: 5000 }));
			}
		} 

	}

};
