// Dependencies
const Command = require('../../structures/Command.js'),
      Guild = require('../../structures/Guild.js');

/**
 * CustomCommand command
 * @extends {Command}
*/
module.exports = class prefix extends Command {
	/**
 	 * @param {Client} client The instantiating client
 	 * @param {CommandData} data The data for the command
	*/
	constructor(bot) {
		// MORE COMMAND SETTINGS CAN BE FOUND IN src/structures/Command
		super(bot, {
			name: 'prefix',
            aliases: ['set-prefix', 'setprefix'],
			guildOnly: true,
			dirname: __dirname,
            ownerOnly: true,
			description: 'change prefix on server.',
			usage: 'HOW SHOULD THE USER USE THIS COMMAND (excluding prefix)',
			cooldown: 5000,
			//examples: ['AN', 'ARRAY', 'OF', 'EXAMPLES'],
			// set to false if u don't want it a slash command VV
			slash: true,
			// The options for slash command https://discord.js.org/#/docs/discord.js/stable/typedef/CommandInteractionOption
			//options: [],
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
	 * @param {settings} settings The settings of the channel the command ran in
 	 * @readonly
	*/
	async run(bot, message, settings ) {
		// A VERY COOL COMMAND
	const prefix = message.args[0];
        
		if(!prefix){
			return message.channel.error(bot.translate('guild/prefix:ISEMPTY'));
		}else if(prefix.length > 4){
			return message.channel.error(bot.translate('guild/prefix:ISUP'));
		}else{
            await updatePrefix(message.guild, prefix);
        }

        async function updatePrefix(guild, prefix) {
			try {
				await guild.updateGuild({ prefix: prefix });
				return message.channel.success(bot.translate('guild/prefix:SUCSSIS', { PREFIX: prefix }));
			} catch (err) {
				bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
				message.channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }).then(m => m.timedDelete({ timeout: 5000 }));
			}
		}
        
        
	}

	/**
	 * Function for recieving interaction.
	 * @param {bot} bot The instantiating client
	 * @param {interaction} interaction The interaction that ran the command
	 * @param {guild} guild The guild the interaction ran in
	 * @readonly
	*/
	async callback(bot, interaction, guild) {
		console.log(guild);
	}
};
