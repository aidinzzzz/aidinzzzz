// Dependencies
const fetch = require('node-fetch'),
	{ MessageEmbed } = require('discord.js'),
	Command = require('../../structures/Command.js');

/**
 * date command
 * @extends {Command}
*/
class reload extends Command {
	/**
   * @param {Client} client The instantiating client
   * @param {CommandData} data The data for the command
  */
	constructor(bot) {
		super(bot, {
        name: 'Reload',
      description: 'Reloads Commands',
      aliases: ['reset', 'flush'],
      admin: true
		});
	}
/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
 	 * @readonly
*/
	async run(bot, message) {
 const module = message.args[0];

    if (!module) {
      const msg = await channel.send('Reloading all modules...');
      await message.context.reloadCommands();
      await msg.edit('Reloading all modules... done!');
      return false;
    }

    const run = await message.context.reloadCommand(module);

    if (run) {
      return channel.send(`Reloaded '${module}'`);
    }

    return channel.send(`Module ${module} doesn't exist!`);
  }
	
}


module.exports = reload;
