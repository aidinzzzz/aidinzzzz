// Dependencies
const fetch = require('node-fetch'),
	{ MessageEmbed } = require('discord.js'),
	Command = require('../../structures/Command.js');




/**
 * date command
 * @extends {Command}
*/
class date extends Command {
	/**
   * @param {Client} client The instantiating client
   * @param {CommandData} data The data for the command
  */
	constructor(bot) {
		super(bot, {
			name: 'slap',
			dirname: __dirname,
			botPermissions: ['SEND_MESSAGES', 'EMBED_LINKS'],
			description: 'slap gif',
			usage: 'slap',
			cooldown: 1000,
			slash: true,
            options: [{
				name: 'user',
				description: 'pickup a user.',
				type: 'USER',
				required: false,
			}]
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
 	 * @readonly
  */
	async run(bot, message) {
    const members = await message.getMember();
		// send 'waiting' message to show bot has recieved message
		const msg = await message.channel.send(message.translate('misc:FETCHING', {
			EMOJI: message.channel.checkPerm('USE_EXTERNAL_EMOJIS') ? bot.customEmojis['loading'] : '', ITEM: this.help.name }));

		// Connect to API and fetch data
		try {
			const data = await fetch('https://nekos.life/api/v2/img/slap').then(res => res.json());
			msg.delete();
            if(message.args.join() != "") {
           const embed = new MessageEmbed()
            .setDescription(`✋ **${message.author.username}** • slaping • **${members[0].user.username}**`)
            .setColor(3426654)
			.setImage(data.url)
            .setTimestamp();
			message.channel.send({ embeds: [embed] });
       }else{
        const embed2 = new MessageEmbed()
            .setColor(3426654)
			.setImage(data.url)
            .setTimestamp();
			message.channel.send({ embeds: [embed2] });
       }
			
		} catch (err) {
			if (message.deletable) message.delete();
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			msg.delete();
			message.channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }).then(m => m.timedDelete({ timeout: 5000 }));
		}
	}

	/**
	 * Function for recieving interaction.
	 * @param {bot} bot The instantiating client
	 * @param {interaction} interaction The interaction that ran the command
	 * @param {guild} guild The guild the interaction ran in
	 * @readonly
	*/
	async callback(bot, interaction, guild) {
		const channel = guild.channels.cache.get(interaction.channelId);
		try {
			const data = await fetch('https://api.keybit.ir/ayamidanid').then(res => res.json());
			interaction.reply({ embeds: [{ color: 'RANDOM', description: `💡 ${data.text}` }] });
		} catch (err) {
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			interaction.reply({ embeds: [channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }, true)], ephemeral: true });
		}
	}
}

module.exports = date;
