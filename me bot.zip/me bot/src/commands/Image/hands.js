// Dependencies
const fetch = require('node-fetch'),
	{ MessageEmbed } = require('discord.js'),
	Command = require('../../structures/Command.js');




/**
 * date command
 * @extends {Command}
*/
class hands extends Command {
	/**
   * @param {Client} client The instantiating client
   * @param {CommandData} data The data for the command
  */
	constructor(bot) {
		super(bot, {
			name: 'hands',
            aliases: ['hand' , 'holdhand'],
			dirname: __dirname,
			botPermissions: ['SEND_MESSAGES', 'EMBED_LINKS'],
			description: 'hands gif',
			usage: 'hands',
			cooldown: 1000,
			slash: true,
            options: [{
				name: 'user',
				description: 'pickup a user.',
				type: 'USER',
				required: false,
			}]
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
 	 * @readonly
  */
	async run(bot, message) {
    const members = await message.getMember();
		// send 'waiting' message to show bot has recieved message
		const msg = await message.channel.send(message.translate('misc:FETCHING', {
			EMOJI: message.channel.checkPerm('USE_EXTERNAL_EMOJIS') ? bot.customEmojis['loading'] : '', ITEM: this.help.name }));

		// Connect to API and fetch data
		try {
			
let messagePrompts = [
  'https://lotus1.sirv.com/hands/109100.gif',
     'https://lotus1.sirv.com/hands/1408693562that-moment-holding-hands-animated-gif.gif',
     'https://lotus1.sirv.com/hands/200.gif',
     'https://lotus1.sirv.com/hands/2541a0f7a8be1a80a27312ac3e1c9e54.gif',
     'https://lotus1.sirv.com/hands/5f3d2997c199674c388dca27df786fc6.gif',
     'https://lotus1.sirv.com/hands/6874747073.gif',
     'https://lotus1.sirv.com/hands/770.gif',
     'https://lotus1.sirv.com/hands/9d8M.gif',
     'https://lotus1.sirv.com/hands/AccurateMeekAzurewingedmagpie-size_restricted.gif',
     'https://lotus1.sirv.com/hands/Xfbp.gif',
     'https://lotus1.sirv.com/hands/anime-hold.gif',
     'https://lotus1.sirv.com/hands/animesher.com_love-holding-hands-animation-1023499.gif',
     'https://lotus1.sirv.com/hands/interlocking.gif',
     'https://lotus1.sirv.com/hands/love-holding-hands.gif',
     'https://lotus1.sirv.com/hands/original.gif',
     'https://lotus1.sirv.com/hands/tumblr_mdiase6ysk1qecl4bo1_500.gif',
    'https://lotus1.sirv.com/hands/tumblr_onnkquUkxy1viiyyio1_500.gif',
  
];

let messageChoice = Math.floor(Math.random() * messagePrompts.length);
   let messagesss = messagePrompts[messageChoice];         
			msg.delete();
            if(message.args.join() != "") {
           const embed = new MessageEmbed()
            .setDescription(`🤚🏻 **${message.author.username}** •  Holding Hands • **${members[0].user.username}**`)
            .setColor(3426654)
			.setImage(messagesss)
            .setTimestamp();
			message.channel.send({ embeds: [embed] });
       }else{
        const embed2 = new MessageEmbed()
         
            .setColor(3426654)
			.setImage(messagesss)
            .setTimestamp();
			message.channel.send({ embeds: [embed2] });
       }
			
		} catch (err) {
			if (message.deletable) message.delete();
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			msg.delete();
			message.channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }).then(m => m.timedDelete({ timeout: 5000 }));
		}
	}

	/**
	 * Function for recieving interaction.
	 * @param {bot} bot The instantiating client
	 * @param {interaction} interaction The interaction that ran the command
	 * @param {guild} guild The guild the interaction ran in
	 * @readonly
	*/
	async callback(bot, interaction, guild) {
		const channel = guild.channels.cache.get(interaction.channelId);
		try {
			const data = await fetch('https://api.keybit.ir/ayamidanid').then(res => res.json());
			interaction.reply({ embeds: [{ color: 'RANDOM', description: `💡 ${data.text}` }] });
		} catch (err) {
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			interaction.reply({ embeds: [channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }, true)], ephemeral: true });
		}
	}
}

module.exports = hands;
