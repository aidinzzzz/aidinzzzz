// Dependencies
const	Command = require('../../structures/Command.js');
const discord = require('discord.js');
const { createCanvas, loadImage } = require('canvas');
const MessageAttachment = require('discord.js');
const intents = ["GUILDS", "GUILD_MEMBERS"];
/**
 * CustomCommand command
 * @extends {Command}
*/
module.exports = class welcome extends Command {
	/**
 	 * @param {Client} client The instantiating client
 	 * @param {CommandData} data The data for the command
	*/
	constructor(bot) {
		// MORE COMMAND SETTINGS CAN BE FOUND IN src/structures/Command
		super(bot, {
			name: 'welcome',
			guildOnly: true,
			dirname: __dirname,
			aliases: ['wel'],
			description: 'Displays user\'s avatar.',
			usage: 'HOW SHOULD THE USER USE THIS COMMAND (excluding prefix)',
			cooldown: 2000,
			// set to false if u don't want it a slash command VV
			slash: true,
			// The options for slash command https://discord.js.org/#/docs/discord.js/stable/typedef/CommandInteractionOption
			options: [],
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
	 * @param {settings} settings The settings of the channel the command ran in
 	 * @readonly
	*/
	async run(bot, message, settings) {
		
        
        
        
//const welcome_channel = bot.channels.cache.get('816973659323236352');


const canvas = createCanvas(850, 300);
const ctx = canvas.getContext('2d');

// Write "Awesome!"
ctx.font = '35px Arial'
ctx.rotate(0)
ctx.fillText('خوش آمدید!', 50, 100)

// Draw line under text
var text = ctx.measureText('خوش آمدید!')
ctx.strokeStyle = 'rgb(255, 255, 255)'
ctx.beginPath()
ctx.lineTo(50, 102)
ctx.lineTo(50 + text.width, 102)
ctx.stroke()

const avatar = canvas.loadImage(user.displayAvatarURL({ format: 'jpg' }));

	// Draw a shape onto the main canvas
	context.drawImage(avatar, 25, 0, 200, canvas.height);
    // Pick up the pen
	context.beginPath();

	// Start the arc to form a circle
	context.arc(125, 125, 100, 0, Math.PI * 2, true);

	// Put the pen down
	context.closePath();

	// Clip off the region you drew on
	context.clip();
    
        // create the attachment 
let attachment = new discord.MessageAttachment(canvas.toBuffer(), 'welcome.png');

welcome_channel.send({ files: [attachment] });
    

        

        
        
		console.log(settings);
	}

	/**
	 * Function for recieving interaction.
	 * @param {bot} bot The instantiating client
	 * @param {interaction} interaction The interaction that ran the command
	 * @param {guild} guild The guild the interaction ran in
	 * @readonly
	*/
	async callback(bot, interaction, guild) {
		console.log(guild);
	}
};
