// Dependencies
const	Command = require('../../structures/Command.js'),
{ Embed } = require('../../utils');
/**
 * CustomCommand command
 * @extends {Command}
*/
module.exports = class sp extends Command {
	/**
 	 * @param {Client} client The instantiating client
 	 * @param {CommandData} data The data for the command
	*/
	constructor(bot) {
		// MORE COMMAND SETTINGS CAN BE FOUND IN src/structures/Command
		super(bot, {
			name: 'sp',
			guildOnly: true,
			dirname: __dirname,
			aliases: ['sp', 'searchporn'],
			description: 'search porn in pornhub.',
			usage: 'sp <search>',
			cooldown: 2000,
			examples: ['AN', 'ARRAY', 'OF', 'EXAMPLES'],
			// set to false if u don't want it a slash command VV
			slash: true,
			// The options for slash command https://discord.js.org/#/docs/discord.js/stable/typedef/CommandInteractionOption
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
	 * @param {settings} settings The settings of the channel the command ran in
 	 * @readonly
	*/
	async run(bot, message) {
	const msg = await message.channel.send(message.translate('nsfw/4k:FETCHING', {
			EMOJI: message.channel.checkPerm('USE_EXTERNAL_EMOJIS') ? bot.customEmojis['loading'] : '', ITEM: this.help.name }));
        
const DabiImages = require("dabi-images");
        
const DabiClient = new DabiImages.Client();
// getting real images
DabiClient.nsfw.real.pussy().then(json => {
    msg.delete();
    message.delete();
    const embed = new Embed(bot, message.guild)
						.setImage(json.url);
					message.channel.send({ embeds: [embed] });

    // outputs data with image url, possible source and other stuff
}).catch(error => {
    console.log(error);
    // outputs error
});



}
    
}
