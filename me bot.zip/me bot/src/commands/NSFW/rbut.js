// Dependencies
const fetch = require('node-fetch'),
	{ Embed } = require('../../utils'),
	Command = require('../../structures/Command.js');

/**
 * Boobs command
 * @extends {Command}
*/
class rbut extends Command {
	/**
 	 * @param {Client} client The instantiating client
 	 * @param {CommandData} data The data for the command
	*/
	constructor(bot) {
		super(bot, {
			name: 'rbut',
			nsfw: true,
			dirname: __dirname,
			aliases: ['rbut'],
			botPermissions: [ 'SEND_MESSAGES', 'EMBED_LINKS'],
			description: 'Look at NSFW images.',
			usage: 'rbut',
			cooldown: 2000,
			slash: true,
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
 	 * @readonly
  */
	async run(bot, message) {
		// send 'waiting' message to show bot has recieved message
		const msg = await message.channel.send(message.translate('nsfw/4k:FETCHING', {
			EMOJI: message.channel.checkPerm('USE_EXTERNAL_EMOJIS') ? bot.customEmojis['loading'] : '', ITEM: this.help.name }));

		try {
            const random = Math.floor(Math.random() * (8482-1000+1)+1000);
            //const random = Math.floor(Math.random() * 8482);
          // const search = `http://api.obutts.ru/butts/${random}`;
         //  const data = await fetch(search).then(res => res.json());
					msg.delete();
            message.delete();
					const embed = new Embed(bot, message.guild)
						.setImage(`http://media.obutts.ru/butts_preview/0${random}.jpg`);
					message.channel.send({ embeds: [embed] });
				
		} catch (err) {
			if (message.deletable) message.delete();
			msg.delete();
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			message.channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }).then(m => m.timedDelete({ timeout: 5000 }));
		}
	}

}

module.exports = rbut;
