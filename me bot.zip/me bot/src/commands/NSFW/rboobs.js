// Dependencies
const fetch = require('node-fetch'),
	{ Embed } = require('../../utils'),
	Command = require('../../structures/Command.js');

/**
 * Boobs command
 * @extends {Command}
*/
class rboobs extends Command {
	/**
 	 * @param {Client} client The instantiating client
 	 * @param {CommandData} data The data for the command
	*/
	constructor(bot) {
		super(bot, {
			name: 'rboobs',
			nsfw: true,
			dirname: __dirname,
			aliases: ['rboob'],
			botPermissions: [ 'SEND_MESSAGES', 'EMBED_LINKS'],
			description: 'Look at NSFW images.',
			usage: 'rboobs',
			cooldown: 2000,
			slash: true,
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
 	 * @readonly
  */
	async run(bot, message) {
		// send 'waiting' message to show bot has recieved message
		const msg = await message.channel.send(message.translate('nsfw/4k:FETCHING', {
			EMOJI: message.channel.checkPerm('USE_EXTERNAL_EMOJIS') ? bot.customEmojis['loading'] : '', ITEM: this.help.name }));

		try {
            const random = Math.floor(Math.random() * (16844-10000+1)+10000);
            //const random = Math.floor(Math.random() * 8482);
          // const search = `http://api.obutts.ru/butts/${random}`;
         //  const data = await fetch(search).then(res => res.json());
            msg.delete();
            message.delete();
					const embed = new Embed(bot, message.guild)
						.setImage(`https://media.oboobs.ru/boobs/${random}.jpg`);
					message.channel.send({ embeds: [embed] });
				
		} catch (err) {
			if (message.deletable) message.delete();
			msg.delete();
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			message.channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }).then(m => m.timedDelete({ timeout: 5000 }));
		}
	}

}

module.exports = rboobs;
