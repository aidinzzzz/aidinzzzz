const Command = require('../../structures/Command.js'),
	Discord = require("discord.js"),
	md5 = require("md5");
const { MessageAttachment } = require('discord.js');
	const Canvas = require('canvas');
      
      
      
      
class Lovecalc extends Command {

	constructor (client) {
		super(client, {
			name: "lovecalc",
			dirname: __dirname,
			enabled: true,
			guildOnly: true,
			aliases: ["love" , "lv"],
			memberPermissions: [],
			botPermissions: [ "SEND_MESSAGES", "EMBED_LINKS" ],
            usage: 'love <user1> [user2]',
			nsfw: false,
			ownerOnly: false,
			cooldown: 1000,
             options: [{
				name: 'user',
				description: 'first user.',
				type: 'USER',
				required: true,
			}, {
				name: 'user2',
				description: 'second user',
				type: 'USER',
				required: false,
			}],
		});
	}

	async run (bot, message , interaction, guild, args) {
        const msg = await message.channel.send(message.translate('misc:FETCHING', {
			EMOJI: message.channel.checkPerm('USE_EXTERNAL_EMOJIS') ? bot.customEmojis['loading'] : '', ITEM: this.help.name }));
        
   
const memberss = await message.getMember();
        
    const firstMember = memberss[0];
    const secondMember = memberss[1];
   
if(!secondMember){
    return msg.edit(` لطفا به این شکل وارد شود love user1 user2 `);
}

		const members = [firstMember, secondMember].sort(
			(a, b) => parseInt(a.id, 10) - parseInt(b.id, 10)
		);
       
		const hash = md5(`${members[0].id}${members[1].user.username}${members[0].user.username}${members[1].id}`
		);

		const string = hash
			.split("")
			.filter(e => !isNaN(e))
			.join("");
		const percent = parseInt(string.substr(0, 2), 10);

        
         
function percent_Discription(){
    if(percent < 10){
        return `😭 این رابطه به هیچ جا نمیرسه`;
    }else if(percent < 20){
        return `😥 خیلی باید تلاش کنی شاید فرجی شد`;
    }else if(percent < 30){
        return `🤐 من نمیدونم ولی این رابطه به جایی نمیرسه`;
    }else if(percent < 40){
        return `🙂 کمه ولی ناامید نشو`;
    }else if(percent < 50){
        return `🙄 امیدوار باش حداقل 20 نیست جای شکرش باقیه`;
    }else if(percent < 60){
        return `😋 خوبه میتونید کنار بیاید`;
    }else if(percent < 70){
        return `😉 خیلی خوبه رابطه بدی نیست`;
    }else if(percent < 80){
        return `😊 بابا بنازم نمیشه با منم خوب باشید؟`;
    }else if(percent < 90){
        return `😍 رابطه خوبی دارین دمتون گرم`;
    }else if(percent < 100){
        return `❤ عالیه عشقتون پایدار`;
    }else{
         return `😶 حرفی ندارم`;
    }
    }
    
   
        
        
      
       // Create a 700x250 pixel canvas and get its context
		// The context will be used to modify the canvas
		const canvas = Canvas.createCanvas(930, 400);
		const context = canvas.getContext('2d');
		// ...
const background = await Canvas.loadImage('https://cdn.discordapp.com/attachments/815173870721957889/950894150562246656/shgsdgkjsdrg1.jpg');

	// This uses the canvas dimensions to stretch the image onto the entire canvas
	context.drawImage(background, 0, 0, canvas.width, canvas.height);

        
    const avatar1 = await Canvas.loadImage(firstMember.user.displayAvatarURL({ format: 'png', dynamic: true, size: 512 }));
    const avatar2 = await Canvas.loadImage(secondMember.user.displayAvatarURL({ format: 'png', dynamic: true, size: 512 }));
        // Slightly smaller text placed above the member's display name
	//context.font = '50px sans-serif';
	//context.fillStyle = '#ffffff';
	//context.fillText('میزان عشق', canvas.width / 2.5, canvas.height / 3.5);
            // Select the font size and type from one of the natively available fonts
	context.font = '250px BALCONIE';
	// Select the style that will be used to fill the text in
	context.fillStyle = '#ffffff';
	// Actually fill the text with a solid color
	context.fillText(`${percent}`, canvas.width / 2.6, canvas.height / 1.4);

        
        
        
    context.font = '50px sans-serif';
	// Select the style that will be used to fill the text in
	context.fillStyle = '#ffffff';
	// Actually fill the text with a solid color
	context.fillText(`${firstMember.user.username}`, 50 , canvas.height / 6);
        
        
        
        
    context.font = '50px sans-serif';
	// Select the style that will be used to fill the text in
	context.fillStyle = '#ffffff';
	// Actually fill the text with a solid color
	context.fillText(`${secondMember.user.username}`, canvas.width / 1.4, canvas.height / 6);
        
    context.font = '35px Nahid';
	// Select the style that will be used to fill the text in
	context.fillStyle = '#ffffff';
	// Actually fill the text with a solid color
	context.fillText(`${percent_Discription()}`, 50 , 380);   
        
        

	// Draw a shape onto the main canvas
	context.drawImage(avatar1, 50, 80, 250, 250);
    context.drawImage(avatar2, 640, 80, 250, 250);
	

	// Use the helpful Attachment class structure to process the file for you
	const attachment = new MessageAttachment(canvas.toBuffer(), 'love-image.png');
        
        
        
        
        
		const embed = new Discord.MessageEmbed()
        .setAuthor({ name:`❤️ Your Love ${percent_Discription()}` })
        .setColor('#d045aa')
        .setTitle(`${firstMember.user.username} ❤️  ${percent}%  ❤️ ${ secondMember.user.username}`)
        .setImage('attachment://love-image.png');
        
        msg.delete();
		message.channel.send({ embeds: [embed] , files: [attachment] });

        
	}

}

module.exports = Lovecalc;