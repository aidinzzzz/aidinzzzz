// Dependencies
const fetch = require('node-fetch'),
	{ MessageEmbed } = require('discord.js'),
	Command = require('../../structures/Command.js');

/**
 * date command
 * @extends {Command}
*/
class date extends Command {
	/**
   * @param {Client} client The instantiating client
   * @param {CommandData} data The data for the command
  */
	constructor(bot) {
		super(bot, {
			name: 'date',
			dirname: __dirname,
			botPermissions: ['SEND_MESSAGES', 'EMBED_LINKS'],
			description: 'نمایش تاریخ و ساعت ایران',
			usage: 'date',
			cooldown: 1000,
			slash: true,
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
 	 * @readonly
  */
	async run(bot, message) {
		// send 'waiting' message to show bot has recieved message
		const msg = await message.channel.send(message.translate('misc:FETCHING', {
			EMOJI: message.channel.checkPerm('USE_EXTERNAL_EMOJIS') ? bot.customEmojis['loading'] : '', ITEM: this.help.name }));

		// Connect to API and fetch data
		try {
			const data = await fetch('https://api.keybit.ir/time/').then(res => res.json());
			msg.delete();
			const embed = new MessageEmbed()
            .setColor('#fa404e')
            .setTitle(`🕒 ساعت : ${data.time12.full.full.en}`)
            .setAuthor({ name: 'تاریخ و ساعت', iconURL: 'https://cdn.discordapp.com/attachments/815173870721957889/935816635862876170/flat-clock-icon-png-11.png' })
           .setDescription("🔮 اطلاعات این بخش فقط برای ریجن آسیا / تهران میباشد ") .setThumbnail('https://cdn.discordapp.com/attachments/815173870721957889/935805882988634132/january-28-calendar-icon-vector-id1295029762.png')

            .addField(  "🪄 تاریخ شمسی : ",`${data.date.full.official.iso.en}`,true)
            .addField(  "🦍 حیوان سال : ",`${data.date.year.animal}`,true)
            .addField(  "نوع سال : ",`${data.date.year.leapyear}`,true)
            .addField(  "🌞 فصل : ",`${data.season.name}`,true)
            .addField(  "🌕 ماه : ",`${data.date.month.name}`,true)
            .addField(  "🌤️ روز  : ",`${data.date.weekday.name}`,true)
            .addField(  "📰 مناسبت های امروز : ",`${data.date.day.local}`,true)
            .setTimestamp();
			message.channel.send({ embeds: [embed] });
		} catch (err) {
			if (message.deletable) message.delete();
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			msg.delete();
			message.channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }).then(m => m.timedDelete({ timeout: 5000 }));
		}
	}

	/**
	 * Function for recieving interaction.
	 * @param {bot} bot The instantiating client
	 * @param {interaction} interaction The interaction that ran the command
	 * @param {guild} guild The guild the interaction ran in
	 * @readonly
	*/
	async callback(bot, interaction, guild) {
		const channel = guild.channels.cache.get(interaction.channelId);
		try {
			const data = await fetch('https://api.keybit.ir/ayamidanid').then(res => res.json());
			interaction.reply({ embeds: [{ color: 'RANDOM', description: `💡 ${data.text}` }] });
		} catch (err) {
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			interaction.reply({ embeds: [channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }, true)], ephemeral: true });
		}
	}
}

module.exports = date;
