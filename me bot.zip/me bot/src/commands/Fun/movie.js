// Dependencies
const fetch = require('node-fetch'),
	{ MessageEmbed } = require('discord.js'),
	Command = require('../../structures/Command.js');




/**
 * date command
 * @extends {Command}
*/
class movie extends Command {
	/**
   * @param {Client} client The instantiating client
   * @param {CommandData} data The data for the command
  */
	constructor(bot) {
		super(bot, {
			name: 'movie',
            aliases: ["movies", "film", "films"],
			dirname: __dirname,
			botPermissions: ['SEND_MESSAGES', 'EMBED_LINKS'],
			description: 'movie info',
			usage: "movie <query>, [page]",
			cooldown: 1000,
			slash: true,
             options: [{
				name: 'movie',
				description: 'movie name',
				type: 'STRING',
				required: true,
			}],
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
 	 * @readonly
  */
	async run(bot, message) {

    if (!message.args.length) return message.channel.send("اووومم چه فیلمی باید جستجو کنم؟");
        
    const [query, page = 1] = message.args.join(" ").split(",");
    if (isNaN(parseInt(page))) return message.channel.send("اوومم صفحه باید عدد باشه.");

    const url = new URL("https://api.themoviedb.org/3/search/movie");
    url.search = new 
    URLSearchParams([["api_key", "c645d7312b729b3e756087ce4c5fcf56"],["query", query],["language","fa"]]);
        
  const msg = await message.channel.send(message.translate('misc:FETCHING', {
			EMOJI: message.channel.checkPerm('USE_EXTERNAL_EMOJIS') ? bot.customEmojis['loading'] : '', ITEM: this.help.name }));

		// Connect to API and fetch data
		try {
  
const data = await fetch(url).then(res => res.json()).catch(() => { throw `I couldn't find a movie with title **${query}** in page ${page}.`; });
            		// send 'waiting' message to show bot has recieved message
		
msg.delete();
  const movie = data.results[parseInt(page) - 1];
    if (!movie) throw `I couldn't find a movie with title **${query}** in page ${page}.`;

           const embed = new MessageEmbed()
   .setURL(movie.homepage)
           .setTitle(`${movie.original_title} (${page} Of ${data.results.length})`)
           .setDescription(`**${movie.title}** - ${movie.overview}`)
    .addFields(
		{ name: 'امتیاز فیلم', value: `${movie.vote_average}`, inline: true },
		{ name: 'تاریخ انتشار', value: `${movie.release_date}`|| "Unknown", inline: true },
		{ name: 'زبان فیلم', value: `${movie.original_language}`, inline: true },
		{ name: 'محتوای +18', value: movie.adult ? "دارد" : "ندارد", inline: true },
	)
            .setImage(`https://image.tmdb.org/t/p/original${movie.poster_path}`);
			message.channel.send({ embeds: [embed] });

		} catch (err) {
			if (message.deletable) message.delete();
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			msg.delete();
			message.channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }).then(m => m.timedDelete({ timeout: 5000 }));
		}
	}

	/**
	 * Function for recieving interaction.
	 * @param {bot} bot The instantiating client
	 * @param {interaction} interaction The interaction that ran the command
	 * @param {guild} guild The guild the interaction ran in
	 * @readonly
	*/
	async callback(bot, interaction, guild) {
		const channel = guild.channels.cache.get(interaction.channelId);
		try {
			const data = await fetch('https://api.keybit.ir/ayamidanid').then(res => res.json());
			interaction.reply({ embeds: [{ color: 'RANDOM', description: `💡 ${data.text}` }] });
		} catch (err) {
			bot.logger.error(`Command: '${this.help.name}' has error: ${err.message}.`);
			interaction.reply({ embeds: [channel.error('misc:ERROR_MESSAGE', { ERROR: err.message }, true)], ephemeral: true });
		}
	}
}

module.exports = movie;
