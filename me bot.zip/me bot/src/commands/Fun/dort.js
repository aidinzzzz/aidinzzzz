const { MessageEmbed } = require('discord.js'),
	Command = require('../../structures/Command.js');
const { MessageActionRow, MessageButton , MessageSelectMenu } = require('discord.js');
/**
 * CustomCommand command
 * @extends {Command}
*/
class dort extends Command {
	/**
 	 * @param {Client} client The instantiating client
 	 * @param {CommandData} data The data for the command
	*/
	constructor(bot) {
		// MORE COMMAND SETTINGS CAN BE FOUND IN src/structures/Command
		super(bot, {
			name: 'dort',
			guildOnly: true,
			dirname: __dirname,
			aliases: ['dort'],
			botPermissions: ['SEND_MESSAGES' , 'EMBED_LINKS'],
			description: 'بات جرات یا حقیقت.',
			usage: 'dort <classic>',
			cooldown: 2000,
			examples: ['dort classic'],
			// set to false if u don't want it a slash command VV
			slash: true,
			// The options for slash command https://discord.js.org/#/docs/discord.js/stable/typedef/CommandInteractionOption
			options: [],
		});
	}

	/**
 	 * Function for recieving message.
 	 * @param {bot} bot The instantiating client
 	 * @param {message} message The message that ran the command
	 * @param {settings} settings The settings of the channel the command ran in
 	 * @readonly
	*/
	async run(bot, message, settings) {
        	// Connect to API and fetch data
		
			
const embed = new MessageEmbed()
            .setColor('#7e43c3')
            .setTitle(`بازی ایجاد شد`)
            .setAuthor({ name: 'بازی جرات یا حقیقت'})
       .setDescription(`خب برای ادامه افرادی که میخواهند در بازی شرکت کنند ری اکشن زیر را لمس کنند`);
        
        
        
 const sbutton = new MessageActionRow()
      .addComponents(
    new MessageButton()
          .setCustomId('start_game_dort')
          .setLabel('شروع بازی')
          .setStyle('SECONDARY')
      );
        

let msgg = await message.channel.send({ embeds: [embed] , components: [ sbutton ] }).then( async mesg => {
const filter = (m) => m.author.id === message.author.id;
const collectorbutton =  message.channel.createMessageComponentCollector(filter ,{ time: 50000 });
    
collectorbutton.on('collect', async i => {
    // Check that user is in the same voice channel
	if (i.customId === 'start_game_dort') {
        const gamestarted = new MessageEmbed()
        .setAuthor({ name: 'بازی جرات یا حقیقت'})
        .setTitle("بازی شروع شد")
        .setDescription('افراد درون بازی در ادامه نشان داده شده اند');
       // await message.channel.send({ embeds: [gamestarted] });
         const StartedButton = new MessageActionRow()
      .addComponents(
    new MessageButton()
          .setCustomId('start_game_dorted')
          .setLabel('بازی شروع شده')
          .setStyle('SECONDARY')
          .setDisabled(true),
          
           new MessageButton()
          .setCustomId('close_game')
          .setLabel('پایان بازی')
          .setStyle('SECONDARY')
          
      );

await i.update({ embeds: [gamestarted] , components: [ StartedButton ]  });
	}

    if (i.customId === 'close_game') {
         const gameend = new MessageEmbed()
        .setAuthor({ name: 'بازی جرات یا حقیقت'})
        .setTitle("بازی بسته شد")
        .setDescription(`بازی به درخواست : <@${message.author.id}> به پایان رسید`);
         
        const endedButton = new MessageActionRow()
      .addComponents(
    new MessageButton()
          .setCustomId('start_game_dorted')
          .setLabel('بازی به اتمام رسید')
          .setStyle('SECONDARY')
          .setDisabled(true)
      );
        
        
        await i.update({ embeds: [gameend] , components: [ endedButton ]  });
         i.deferUpdate();
    }
});
    
    
    collectorbutton.on('end', collected => {
    console.log(`Collected ${collected.size} items`);
});
   // await i.reactions.removeAll().catch(error => console.error('Failed to clear reactions: ', error));
   await mesg.react("🤚🏻");   
});

	//	console.log(settings);
	}

	/**
	 * Function for recieving interaction.
	 * @param {bot} bot The instantiating client
	 * @param {interaction} interaction The interaction that ran the command
	 * @param {guild} guild The guild the interaction ran in
	 * @readonly
	*/
	async callback(bot, interaction) {
        

        
    // console.log(guild);
	}
}
module.exports = dort;