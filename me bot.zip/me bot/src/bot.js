// Dependencies
const Client = require('./base/Egglord.js');
const { MessageActionRow, MessageButton , MessageSelectMenu } = require('discord.js');
require('./structures');
// Dependencies
const { Embed } = require('./utils'),
    guild = require('discord.js'),
    fetch = require('node-fetch');
const bot = new Client(),
	{ promisify } = require('util'),
	readdir = promisify(require('fs').readdir),
	path = require('path');
const intents = ["GUILDS", "GUILD_MEMBERS"];
/* ------------------------ME CODE---------------------------*/
// if bot is redy to use
bot.on('ready', guilds => {
const guild = bot.guilds.cache.get('716195351329112064');
//console.log(guild.settings.musicChannel);
// -----------------------------  Date voice Stat----//
setInterval(() => {
const fetch = require('node-fetch');
fetch('https://api.keybit.ir/time').then(response => {
  return response.json();
}).then(data => {
    // date voice channel
    const channeldate = guild.channels.cache.get('936892791835996160')
    channeldate.setName(`🔮 ${data.date.weekday.name}・${data.date.day.number.en}・${data.date.month.name} 🔮`); 
}).catch(err => {
    console.log(err);
    const channeldate = guild.channels.cache.get('936892791835996160')
    channeldate.setName(`🔮 ${err}`); 
});
}, 3600000);
//-----------------------------//
});
// in channel massage reaction section
bot.on('messageCreate', (message) => {
const guild = message.guild;
if(message.channel.id === guild.settings.musicChannel){
    message.fetch({ limit: 1 }).then(msg => {
  //console.log(bot.settings.prefix);
    if(message.author.id === bot.user.id) return;
    setTimeout(() => msg.delete(), 3000)
    if(msg.content.startsWith(".")) return;
    const interaction = msg;
   // const guild = bot.guilds.cache.get('716195351329112064');
    const args = new Map().set('track', { value: `${msg.content}` });
    bot.commands.get('play').callback(bot,interaction,guild,args);
    //setTimeout(() => msg.delete(), 3000)
})
}

//nice music reactions
if(message.channel.id === '777574167763353631'){
      message.channel.fetch({ limit: 1 }).then(messages => {
          message.react("<:love:853409935877603338> ")
      })
}
//deklame reactions
if(message.channel.id === '716195351329112068'){
      message.channel.fetch({ limit: 1 }).then(messages => {
          message.react("<:like:853409548030574602> ")
      })
}
//poetry reactions
if(message.channel.id === '779197694669226004'){
      message.channel.fetch({ limit: 1 }).then(messages => {
          message.react("<:like:853409548030574602>")
      })
}
//two-bits reactions
if(message.channel.id === '878478915285422141'){
      message.channel.fetch({ limit: 1 }).then(messages => {
          message.react("<:like:853409548030574602>")
      })
}
//media reactions
if(message.channel.id === '797282317738835968'){
      message.channel.fetch({ limit: 1 }).then(messages => {
          message.react("<:like:853409548030574602>")
      })
}
});

bot.on("interactionCreate", async interaction => {
 const guild = bot.guilds.cache.get('716195351329112064');
        if (!interaction.isSelectMenu()) return;
            const member = interaction.member;
          //  const interaction = menuInteraction;  
   // menuInteraction = interaction;
    if(interaction.values[0] === "radios") {
             const args = new Map().set('track', { value: "http://stream.radiojavan.com/radiojavan" });
        bot.commands.get('play').callback(bot, interaction, guild, args);
        // http://stream.radiojavan.com/radiojavan
    }else if(interaction.values[0] === "pop_R"){
           const args = new Map().set('track', { value: "https://streams.ilovemusic.de/iloveradio14.mp3" });
        bot.commands.get('play').callback(bot, interaction, guild, args);
        // https://streams.ilovemusic.de/iloveradio14.mp3
    }else if(interaction.values[0] === "clasic_R"){
        const args = new Map().set('track', { value: "http://ais.absoluteradio.co.uk/absolute70s.mp3" });
        bot.commands.get('play').callback(bot, interaction, guild, args); 
        // http://ais.absoluteradio.co.uk/absolute70s.mp3
    }else if(interaction.values[0] === "hiphop_R"){
        const args = new Map().set('track', { value: "https://streams.ilovemusic.de/iloveradio3.mp3" });
        bot.commands.get('play').callback(bot, interaction, guild, args);
        // https://streams.ilovemusic.de/iloveradio3.mp3
    }else if(interaction.values[0] === "rock_R"){
        const args = new Map().set('track', { value: "http://icy-e-bab-04-cr.sharp-stream.com/absoluteclassicrock.mp3" });
        bot.commands.get('play').callback(bot, interaction, guild, args);
        // http://icy-e-bab-04-cr.sharp-stream.com/absoluteclassicrock.mp3
    }else if(interaction.values[0] === "chill_R"){
        const args = new Map().set('track', { value: "https://streams.ilovemusic.de/iloveradio17.mp3" });
        bot.commands.get('play').callback(bot, interaction, guild, args);
        // https://streams.ilovemusic.de/iloveradio17.mp3
    }else if(interaction.values[0] === "Aydin"){
        const args = new Map().set('track', { value: "https://open.spotify.com/playlist/2MgXklj9dtm9ypOSZO1KhX?si=91495e8c75794ef6" });
        bot.commands.get('play').callback(bot, interaction, guild, args , member);
        // play list aydin
    }else if(interaction.values[0] === "Mobina"){
        const args = new Map().set('track', { value: "https://open.spotify.com/playlist/3CmJOmvGiOkefkOyAfyrVE?si=27da620330a74342" });
        bot.commands.get('play').callback(bot, interaction, guild, args , member);
        // play list mobina
    }
    
             
});

// join and left section
bot.on("guildMemberAdd", onMemberJoinOrLeave);
bot.on("guildMemberRemove", onMemberJoinOrLeave);
async function onMemberJoinOrLeave(member) {
    // Ignore its own leave event
    if (member.id === bot.user.id) return;
  // if (bot.guild.id != bot.guilds.cache.get('716195351329112064')) return;
    const guild = bot.guilds.cache.get('716195351329112064'); // server id
    
    // If the member is "deleted", they have left
    if (member.deleted) {
    // members count voice channel
    const memberCount = guild.memberCount;
    const channelAMember = guild.channels.cache.get('936859752124801034')

    channelAMember.setName(`👤 Members : ${memberCount}`)

    } else {

    // members count voice channel
    const memberCount = guild.memberCount;
    const channelAMember = guild.channels.cache.get('936859752124801034')
    channelAMember.setName(`👤 Members : ${memberCount}`)

    }

}

// Load commands
(async () => {
	// load commands
	await loadCommands();

	// load events
	await loadEvents();

	// load translations
	bot.translations = await require('./helpers/LanguageManager')();

	// Connect bot to database
	bot.mongoose.init(bot);

	// load up adult site block list
	bot.fetchAdultSiteList();

	// Connect bot to discord API
	const token = bot.config.token;
	bot.login(token).catch(e => bot.logger.error(e.message));
})();
// load commands
async function loadCommands() {
	const cmdFolders = (await readdir('./src/commands/')).filter((v, i, a) => a.indexOf(v) === i);
	bot.logger.log('=-=-=-=-=-=-=- Loading command(s): 137 -=-=-=-=-=-=-=');
	// loop through each category
	cmdFolders.forEach(async (dir) => {
		if (bot.config.disabledPlugins.includes(dir) || dir == 'command.example.js') return;
		const commands = (await readdir('./src/commands/' + dir + '/')).filter((v, i, a) => a.indexOf(v) === i);
		// loop through each command in the category
		commands.forEach((cmd) => {
			if (bot.config.disabledCommands.includes(cmd.replace('.js', ''))) return;
			try {
				bot.loadCommand('./commands/' + dir, cmd);
			} catch (err) {
				if (bot.config.debug) console.log(err);
				bot.logger.error(`Unable to load command ${cmd}: ${err}`);
			}
		});
	});
}
// load events
async function loadEvents() {
	const evtFolder = await readdir('./src/events/');
	bot.logger.log('=-=-=-=-=-=-=- Loading events(s): 44 -=-=-=-=-=-=-=');
	evtFolder.forEach(async folder => {
		const folders = await readdir('./src/events/' + folder + '/');
		folders.forEach(async file => {
			delete require.cache[file];
			const { name } = path.parse(file);
			try {
				const event = new (require(`./events/${folder}/${file}`))(bot, name);
				bot.logger.log(`Loading Event: ${name}`);
				if (folder == 'giveaway') {
					bot.giveawaysManager.on(name, (...args) => event.run(bot, ...args));
				} else if (folder == 'audio') {
					bot.manager.on(name, (...args) => event.run(bot, ...args));
				} else {
					bot.on(name, (...args) => event.run(bot, ...args));
				}
			} catch (err) {
				bot.logger.error(`Failed to load Event: ${name} error: ${err.message}`);
			}
		});
	});
}
// handle unhandledRejection errors
process.on('unhandledRejection', err => {
	bot.logger.error(`Unhandled promise rejection: ${err.message}.`);

	// show full error if debug mode is on
	console.log(err);
});