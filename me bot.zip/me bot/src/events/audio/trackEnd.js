// Dependencies
const { Embed } = require('../../utils'),
	Event = require('../../structures/Event');
const { MessageActionRow, MessageButton , MessageSelectMenu } = require('discord.js');

/**
 * Track end event
 * @event AudioManager#TrackEnd
 * @extends {Event}
*/
class TrackEnd extends Event {
	constructor(...args) {
		super(...args, {
			dirname: __dirname,
		});
	}

	/**
	 * Function for recieving event.
	 * @param {bot} bot The instantiating client
	 * @param {Player} player The player that's track ended
	 * @param {Track} track The track that ended
	 * @readonly
	*/
async run(bot, player, track) {
/*
   // when track finishes add to previous songs array
const guild = bot.guilds.cache.get('716195351329112064'); // server id
guild.channels.cache.get("948005672543473694").messages.fetch("948005842475683870").then( async msg => {
//----------------------------------------------
const picture =  new Embed(bot, guild)
.setColor('#4853d8')
.setImage(require('../../assets/json/defaultGuildSettings.json').PlayerImage).setTimestamp(false);
//----------------------------------------------
const queue =  new Embed(bot, guild)
.setColor('#4853d8')
.setTitle(`**Queue of Lotus Music**`)
.setThumbnail("https://cdn.discordapp.com/attachments/847249803565596683/938998808291967017/a38cc4d49e8f32f92a346265f7c050ea.png")
.setDescription(`**Currently there are 0 Songs in the Queue**`)
.setTimestamp(false);
//----------------------------------------------
const PlayerMusic =  new Embed(bot, guild)
.setColor('#4853d8')
.setAuthor({ name: `» Lotus Music v1.2` , iconURL: `${guild.iconURL()}`})
.setTitle("No song playing currently")
.setDescription(`>>> I support <:YTicon:939355466402791454> Youtube, <:SPicon:939355458878201948> Spotify, <:SCicon:939355451332657152> Soundcloud and <:MPicon:939355445062144021> Direct MP3 Links!`)
.setImage("https://cdn.discordapp.com/attachments/900917419927797801/948478808330231808/CanineSameEwe-max-1mb.gif")
.setFooter({ text: 'Lotus Music', iconURL: 'https://cdn.discordapp.com/attachments/847249803565596683/938998808291967017/a38cc4d49e8f32f92a346265f7c050ea.png' })
.setTimestamp(false);
//----------------------------------------------
    const SelectButton = new MessageActionRow()
      .addComponents(
    new MessageButton()
          .setCustomId('pause')
          .setLabel('⏸️ Pause')
          .setStyle('SECONDARY').setDisabled(true),
    new MessageButton()
          .setCustomId('skip')
          .setLabel('⏭️ Skip')
          .setStyle('PRIMARY').setDisabled(true),
    new MessageButton()
          .setCustomId('stop')
          .setLabel('⏹️ Stop')
          .setStyle('DANGER').setDisabled(true),
    new MessageButton()
          .setCustomId('shuffle')
          .setLabel('🔀 Shuffle')
          .setStyle('PRIMARY').setDisabled(true),
    new MessageButton()
          .setCustomId('queue')
          .setLabel('🔂 Loop')
          .setStyle('SUCCESS').setDisabled(true),
      );   
    
    
    
 const radiomenu = new MessageActionRow()
			.addComponents(
				new MessageSelectMenu()
					.setCustomId('radio')
					.setPlaceholder('Choose A Radio Station')
.addOptions([
{label: ' 📻 ・ Radio Javan',description: 'Iranian Radio',value: 'radios',},
{label: ' 🍿 ・ POP',description: 'English Radio',value: 'pop_R',},
{label: ' 🏛️ ・ CLASIC',description: 'English Radio',value: 'clasic_R',},
{label: ' 👓 ・ HIP HOP',description: 'English Radio',value: 'hiphop_R',},
{label: ' 🤘🏻 ・ ROCK',description: 'English Radio',value: 'rock_R',},
{label: ' 🌶️ ・ CHILL',description: 'Light Music Radio',value: 'chill_R',},
{label: ' 💜 ・ Aydin PlayList ',description: 'PlayList Aydin',value: 'Aydin',},
{label: ' 💗 ・ Mobina PlayList ',description: 'PlayList Mobina',value: 'Mobina',}
]),
            );
    
    
await msg.edit( {content: `
`, embeds: [picture , PlayerMusic ] , components: [ SelectButton , radiomenu] }); 
  
  

   });
      */      
        
  player.addPreviousSong(track)
		
	}
}

module.exports = TrackEnd;
