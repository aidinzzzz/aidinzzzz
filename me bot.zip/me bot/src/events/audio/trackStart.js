// Dependencies
const { Embed , time: { getReadableTime } } = require('../../utils'),
Event = require('../../structures/Event'),
{ splitBar } = require('string-progressbar');
const Discord = require('discord.js');
const { MessageActionRow, MessageButton , MessageSelectMenu } = require('discord.js');
//const prettyMilliseconds = require('pretty-ms');
/**
 * Track start event
 * @event AudioManager#TrackStart
 * @extends {Event}
*/
class TrackStart extends Event {
	constructor(...args) {
		super(...args, {
			dirname: __dirname,
		});
	}

	/**
   * Function for recieving event.
	 * @param {bot} bot The instantiating client
	 * @param {Player} player The player that's track started
	 * @param {Track} track The track that started
	 * @readonly
	*/
	async run(bot, player, track ) {
        // Get current song information
        const { title, requester, thumbnail, uri, duration } = player.queue.current;
		const end = (duration > 6.048e+8) ? bot.translate('music/np:LIVE') : new Date(duration).toISOString().slice(11, 19);
	
// in channel massage reaction section
const guild = bot.guilds.cache.get(player.guild);// server id
const musicchanned = guild.settings.musicChannel;
    guild.channels.cache.get(musicchanned).messages.fetch(guild.settings.musicMessage).then( async msg => {
const picture =  new Embed(bot,guild)
.setColor('#4853d8').setImage(require('../../assets/json/defaultGuildSettings.json').PlayerImage).setTimestamp(false);

    // fetch data to show on pages
		const { title, requester, duration, uri } = player.queue.current;
		const parsedDuration = getReadableTime(duration);
		const parsedQueueDuration = getReadableTime(player.queue.reduce((prev, curr) => prev + curr.duration, 0) + player.queue.current.duration);

const songStrings = [];
for (let i = player.queue.length - 1; i >= 0; i--) {
    const song = player.queue[i];
    songStrings.push(`${i+1} . ${song.title} \`[${getReadableTime(song.duration)}]\`\n`);
}
const trakrequested = bot.guilds.cache.get(player.guild).members.cache.get(track.requester.id).username;
// embld player
const PlayerMusic =  new Embed(bot, bot.guilds.cache.get(player.guild))
.setColor(bot.guilds.cache.get(player.guild).members.cache.get(track.requester.id).displayHexColor)
.setAuthor({ name: `Playing for [${getReadableTime(track.duration)}]` , iconURL: "https://cdn.discordapp.com/attachments/815173870721957889/948046157681164328/859459305152708630.gif"})
.setTimestamp(false);
try{
    if (!player.queue.current.isSeekable){
     throw new Error(`It is steam show`);
}
PlayerMusic.setTitle(`${track.title}`);
PlayerMusic.setFooter({ text: `${trakrequested} Request This  ・ [${track.author}] `, iconURL: `${bot.guilds.cache.get(player.guild).members.cache.get(track.requester.id).displayAvatarURL()}` })
}catch (error) {
PlayerMusic.setTitle(`LIVE STREAM - ${track.author}`);
PlayerMusic.setFooter({ text: `LIVE STREAM [${track.author}] `, iconURL: `${bot.guilds.cache.get(player.guild).members.cache.get(track.requester.id).displayAvatarURL()}` })
}
try{
    if (!(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,4}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g).test(track.displayThumbnail("hqdefault"))) {
        throw new Error(`Invalid URL`);
    }
    PlayerMusic.setImage(track.displayThumbnail("hqdefault"));
}
catch (error) {
 PlayerMusic.setImage(require('../../assets/json/defaultGuildSettings.json').PlayerdefultImage);
}

const radiomenu = new MessageActionRow().addComponents(
new MessageSelectMenu().setCustomId('radio').setPlaceholder('Choose A Radio Station')
.addOptions([
{label: ' 📻 ・ Radio Javan',description: 'Iranian Radio',value: 'radios',},
{label: ' 🍿 ・ POP',description: 'English Radio',value: 'pop_R',},
{label: ' 🏛️ ・ CLASIC',description: 'English Radio',value: 'clasic_R',},
{label: ' 👓 ・ HIP HOP',description: 'English Radio',value: 'hiphop_R',},
{label: ' 🤘🏻 ・ ROCK',description: 'English Radio',value: 'rock_R',},
{label: ' 🌶️ ・ CHILL',description: 'Light Music Radio',value: 'chill_R',},
{label: ' 💜 ・ Aydin PlayList ',description: 'PlayList Aydin',value: 'Aydin',},
{label: ' 💗 ・ Mobina PlayList ',description: 'PlayList Mobina',value: 'Mobina',}
]),
);

const StreamButton = new MessageActionRow().addComponents(
    new MessageButton().setCustomId('pause').setLabel('⏸️ Pause').setStyle('PRIMARY'),
    new MessageButton().setCustomId('skip').setLabel('⏭️ Skip').setStyle('PRIMARY'),
    new MessageButton().setCustomId('stopp').setLabel('❌ Disconnect').setStyle('SECONDARY'),
    new MessageButton().setCustomId('volume10Down').setLabel('🔉 Volume Down').setStyle('SECONDARY'),
    new MessageButton().setCustomId('volume10Up').setLabel('🔊 Volume Up').setStyle('SECONDARY'),
);

const SelectButton = new MessageActionRow().addComponents(
    new MessageButton().setCustomId('pause').setLabel('⏸️ Pause').setStyle('PRIMARY'),
    new MessageButton().setCustomId('skip').setLabel('⏭️ Skip').setStyle('PRIMARY'),
    new MessageButton().setCustomId('stopp').setLabel('❌ Disconnect').setStyle('SECONDARY'),
    new MessageButton().setCustomId('shuffle').setLabel('🔀 Shuffle').setStyle('PRIMARY'),
    new MessageButton().setCustomId('songloop').setLabel('🔂 Song').setStyle('SUCCESS'),
);

const SelectButtons = new MessageActionRow().addComponents(
    new MessageButton().setCustomId('queueloop').setLabel('🔂 Queue').setStyle('SUCCESS'),
    new MessageButton().setCustomId('song10secP').setLabel('⏪ -10 Sec').setStyle('PRIMARY'),
    new MessageButton().setCustomId('song10secN').setLabel('⏩ +10 Sec').setStyle('PRIMARY'),
    new MessageButton().setCustomId('volume10Down').setLabel('🔉 Volume Down').setStyle('SECONDARY'),
    new MessageButton().setCustomId('volume10Up').setLabel('🔊 Volume Up').setStyle('SECONDARY'),
);
    
//function for playlist more than 15 trank
function and_mor(){
    if(player.queue.length > 15){
        const x = player.queue.length - 15;
        return `And **${x}** More...`;
    }else{
        return ``;
    }
}

if(!player.queue.current.isSeekable){
await msg.edit({content: `
`, embeds: [picture , PlayerMusic] , components: [StreamButton] });
}else if(player.queue.length > 1){
   await msg.edit({content: `**Queue list: ${player.queue.length}**\n${and_mor()}\n${songStrings.slice(-15).join('')}`, embeds: [PlayerMusic] , components: [SelectButton,SelectButtons] });
}else{
  await msg.edit({content: `
`, embeds: [picture , PlayerMusic ] , components: [ SelectButton,SelectButtons] }); 
}
});
        
		// clear timeout (for queueEnd event)
		if (player.timeout != null) return clearTimeout(player.timeout);
	}
}

module.exports = TrackStart;
