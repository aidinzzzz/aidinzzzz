// Dependencies
const { Embed } = require('../../utils'),
	Event = require('../../structures/Event');
const { MessageActionRow, MessageButton , MessageSelectMenu } = require('discord.js');

/**
 * Queue end event
 * @event AudioManager#QueueEnd
 * @extends {Event}
*/
class QueueEnd extends Event {
	constructor(...args) {
		super(...args, {
			dirname: __dirname,
		});
	}

	/**
	 * Function for recieving event.
	 * @param {bot} bot The instantiating client
	 * @param {Player} player The player that's queue ended
	 * @readonly
	*/
	async run(bot, player) {
     
        // when track finishes add to previous songs array
const guild = bot.guilds.cache.get(player.guild);// server id // server id
const musicchanned = guild.settings.musicChannel;
    guild.channels.cache.get(musicchanned).messages.fetch(guild.settings.musicMessage).then( async msg => {
//----------------------------------------------
const picture =  new Embed(bot, guild)
.setColor('#4853d8')
.setImage(require('../../assets/json/defaultGuildSettings.json').PlayerImage).setTimestamp(false);
    function guidimage(){
    if(!guild.iconURL()){
      return require('../../assets/json/defaultGuildSettings.json').PlayerIcon;
    }else{
      return guild.iconURL();
    }
    }
//----------------------------------------------
const PlayerMusic =  new Embed(bot, guild)
.setColor('#4853d8')
.setAuthor({ name: `» Lotus Music ${require('../../assets/json/defaultGuildSettings.json').PlayerVersion}` , iconURL: `${guidimage()}`})
.setTitle("No song playing currently")
.setDescription(`>>> I support <:YTicon:939355466402791454> Youtube, <:SPicon:939355458878201948> Spotify, <:SCicon:939355451332657152> Soundcloud and <:MPicon:939355445062144021> Direct MP3 Links!`)
.setImage(require('../../assets/json/defaultGuildSettings.json').PlayerImageIdle)
.setFooter({ text: 'Lotus Music', iconURL: require('../../assets/json/defaultGuildSettings.json').PlayerIcon })
.setTimestamp(false);
//----------------------------------------------
    const SelectButton = new MessageActionRow().addComponents(
    new MessageButton().setCustomId('pause').setLabel('⏸️ Pause').setStyle('SECONDARY').setDisabled(true),
    new MessageButton().setCustomId('skip').setLabel('⏭️ Skip').setStyle('PRIMARY').setDisabled(true),
    new MessageButton().setCustomId('stop').setLabel('⏹️ Stop').setStyle('DANGER').setDisabled(true),
    new MessageButton().setCustomId('shuffle').setLabel('🔀 Shuffle').setStyle('PRIMARY').setDisabled(true),
    new MessageButton().setCustomId('queue').setLabel('🔂 Loop').setStyle('SUCCESS').setDisabled(true),
      );   

 const radiomenu = new MessageActionRow().addComponents(
				new MessageSelectMenu().setCustomId('radio').setPlaceholder('Choose A Radio Station')
.addOptions([
{label: ' 📻 ・ Radio Javan',description: 'Iranian Radio',value: 'radios',},
{label: ' 🍿 ・ POP',description: 'English Radio',value: 'pop_R',},
{label: ' 🏛️ ・ CLASIC',description: 'English Radio',value: 'clasic_R',},
{label: ' 👓 ・ HIP HOP',description: 'English Radio',value: 'hiphop_R',},
{label: ' 🤘🏻 ・ ROCK',description: 'English Radio',value: 'rock_R',},
{label: ' 🌶️ ・ CHILL',description: 'Light Music Radio',value: 'chill_R',},
{label: ' 💜 ・ Aydin PlayList ',description: 'PlayList Aydin',value: 'Aydin',},
{label: ' 💗 ・ Mobina PlayList ',description: 'PlayList Mobina',value: 'Mobina',}
]),
);
    
await msg.edit( {content: `
`, embeds: [picture , PlayerMusic ] , components: [ SelectButton , radiomenu] }); 
  
});
        
        

		// When the queue has finished
		//player.timeout = setTimeout(() => {

			// Don't leave channel if 24/7 mode is active
			if (player.twentyFourSeven) return;
		
			//bot.channels.cache.get(player.textChannel)?.send({ embeds: [embed] }).then(m => m.timedDelete({ timeout: 15000 }));
			player.destroy();
	//	}, 180000);
	}
}

module.exports = QueueEnd;
