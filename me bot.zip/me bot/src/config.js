const config = {
	ownerID: ['852990188850905118'],
    MainServer: ['716195351329112064'],
	token: 'OTAxMTQyNDI3Nzg2NzAyODU5.YXLkSQ.2CYQQIlGa6b51UzNLZmo_17fdoA',
    
    // serv.com api acsses
servclientId: "AFKLKRQb8RLKsf7r565PxMWFibI",
servclientSecret: "YpQIqHFmIp9yF0upuVKeDt5LxojbPgqJlU+BNyjg3Us+tSnRBEohyaz/uZi+PtFW4gfu9L9Tdf2fEIjYssGPhQ==",
    
    
	// For looking up Twitch, Fortnite, Steam accounts
	api_keys: {
		// https://dev.twitch.tv/console/apps
		twitch: {
			clientID: '0u9pnrxp4vqohnrmekcrruoydkxurh' , //'0u9pnrxp4vqohnrmekcrruoydkxurh'
			clientSecret: 'law5c70mrxyjfm9jos6niuws4riy9w', //'law5c70mrxyjfm9jos6niuws4riy9w'
		},
		// https://fortnitetracker.com/site-api
		fortnite: '',
		// https://steamcommunity.com/dev
		steam: '1A158017785C4A03669A6AB76194B736',
		// https://developer.spotify.com/documentation/web-api/
		spotify: {
			iD: '7344f1294ef54da4a210c9b90113805e',
			secret: '0f8bffe3fe93467a954d1cc046ffee0e',
		},
		// Your Ubisoft email and password (You don't need to enable anything)
		rainbow: {
			email: '',
			password: '',
		},
		// https://genius.com/developers
genuis:'j1l37759YUjHpW6J4UR3ZAA_MOZuL9SktRtb99rWgACmKVN4sGqN08sKBTdNyPrRwkA0Uk14Gfwb1UkpYiOtYw',
		// https://api.amethyste.moe/
		amethyste: '7bc822667c8bc823634463c478013632c5095100e2ee61eee12735c17da9a78f20defbb6ef45b2c8d97ff6f2021fa3e44fe05a8e944a0915f913287bae0420b8',
	},
	// add plugins/commands here if you don't want them loaded in the bot.
	disabledCommands: [],
	disabledPlugins: [],
	websiteURL: 'http://dl.webnma.com/lotusweb/',
	// your support server
	SupportServer: {
		// Link to your support server
		link: 'https://discord.gg/rSEhRbNtyH',
		// Your support's server ID
		GuildID: '716195351329112064',
		// This for using the suggestion command on your server
		ModRole: '805451972039540736',
		// What channel to post the suggestions
		SuggestionChannel: '847249803565596683',
		// Where the bot will send Guild join/leave messages to
		GuildChannel: '847249803565596683',
		// Where rate limits will be sent to, for investigation
		rateLimitChannelID: '847249803565596683',
	},
	API: {
		port: 2082,
		secure: false,
		token: '',
	},
	// URL to mongodb
	MongoDBURl: 'mongodb+srv://aydin:hvmjdN8HzgMLuWBS@discordbot.8rkja.mongodb.net/discordBot?retryWrites=true&w=majority',
	// embed colour
	embedColor: 'RANDOM',
	// This will spam your console if you enable this but will help with bug fixing
	debug: false,
};

module.exports = config;
